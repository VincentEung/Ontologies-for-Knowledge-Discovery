package applications;

import java.util.List;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.query.Query;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.Literal;
import org.apache.jena.rdf.model.Model;
import java.io.FileOutputStream;
import java.io.OutputStream;
import org.apache.jena.util.FileManager;


public class Main {

    public static void main(String[] args) {
        String csvFilePath = "articles_data.csv";
        String rdfOutputFile = "output.rdf";

        List<Article> articles = CSVReader.readCSV(csvFilePath);

        CSVToRDFConverter.convertToRDF(articles, rdfOutputFile);

        System.out.println("Conversion terminée. RDF enregistré à : " + rdfOutputFile);

        Model model = JenaModelBuilder.createJenaModel(articles);



     // SPARQL queries
        System.out.println("Classify articles by dates:");
        JenaModelBuilder.retrieveLatestArticles(model);

        System.out.println("----------------------------------------");
        System.out.println("Count the number of articles by domain:");
        JenaModelBuilder.analyzePopularDomains(model);

        System.out.println("----------------------------------------");
        System.out.println("All articles with type Actuality: ");
        JenaModelBuilder.findArticlesWithActualityType(model);


        System.out.println("----------------------------------------");
        System.out.println("All articles with type Analyze and their author: ");
        JenaModelBuilder.findArticlesWithAnalyzeType(model);


        System.out.println("----------------------------------------");
        System.out.println("Count the number of articles by language: ");
        JenaModelBuilder.countArticlesByLanguage(model);


        System.out.println("----------------------------------------");
        System.out.println("All articles with parution date in 2024: ");
        JenaModelBuilder.filterArticlesByDate(model);


        System.out.println("----------------------------------------");
        System.out.println("All articles about cinema: ");
        JenaModelBuilder.allCinemaArticles(model);


        System.out.println("----------------------------------------");
        System.out.println("All articles that contain 'Réseaux sociaux' in their title: ");
        JenaModelBuilder.findArticlesWithTitleContainingSpecificWord(model);


        System.out.println("----------------------------------------");
        System.out.println("Articles from bbc.com: ");
        JenaModelBuilder.queryArticlesFromSource(model);


        System.out.println("----------------------------------------");
        System.out.println("Articles written by Aurélien Carle: ");
        JenaModelBuilder.queryArticlesByAuthor(model);

     // Construct Queries
        System.out.println("-------------------Construct Queries---------------------");

        System.out.println("Before enrichment:");
        countTriples(model);

        enrichModelWithConstruct(model,"PREFIX ex: <http://example.org/>\n" +
    	        "CONSTRUCT {\n" +
    	        "  ?article ex:hasGenre ?genre .\n" +
    	        "}\n" +
    	        "WHERE {\n" +
    	        "  ?article ex:topic ?topic .\n" +
    	        "  BIND (\n" +
    	        "    IF(CONTAINS(LCASE(?topic), \"technology\"), \"Technology\",\n" +
    	        "      IF(CONTAINS(LCASE(?topic), \"food\"), \"Culinary\",\n" +
    	        "        IF(CONTAINS(LCASE(?topic), \"life\"), \"Lifestyle\",\n" +
    	        "          IF(CONTAINS(LCASE(?topic), \"Artificial Intelligence\"), \"Technology\",\n" +
    	        "            IF(CONTAINS(LCASE(?topic), \"cinema\"), \"Cinema\",\n" +
    	        "              IF(CONTAINS(LCASE(?topic), \"social\"), \"Social\",\n" +
    	        "                \"Other\"\n" +
    	        "              )\n" +
    	        "            )\n" +
    	        "          )\n" +
    	        "        )\n" +
    	        "      )\n" +
    	        "    ) AS ?genre\n" +
    	        "  )\n" +
    	        "}");

        enrichModelWithConstruct(model,"PREFIX ex: <http://example.org/>\n" +
                "CONSTRUCT {\n" +
                "  ?article ex:targetsLinguisticRegion ?region .\n" +
                "}\n" +
                "WHERE {\n" +
                "  ?article ex:language ?lang .\n" +
                "  BIND (\n" +
                "    IF(?lang = \"French\", \"Francophone\",\n" +
                "      IF(?lang = \"English\", \"Anglophone\",\n" +
                "        \"Other\"\n" +
                "      )\n" +
                "    )\n" +
                "    AS ?region\n" +
                "  )\n" +
                "}");

        enrichModelWithConstruct(model,"PREFIX ex: <http://example.org/>\n" +
                "PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n" +
                "CONSTRUCT {\n" +
                "  ?article ex:publishedInQuarter ?quarter .\n" +
                "}\n" +
                "WHERE {\n" +
                "  ?article ex:date ?date .\n" +
                "  BIND (\n" +
                "    IF(MONTH(xsd:dateTime(?date)) >= 1 && MONTH(xsd:dateTime(?date)) <= 3, \"Q1\",\n" +
                "      IF(MONTH(xsd:dateTime(?date)) >= 4 && MONTH(xsd:dateTime(?date)) <= 6, \"Q2\",\n" +
                "        IF(MONTH(xsd:dateTime(?date)) >= 7 && MONTH(xsd:dateTime(?date)) <= 9, \"Q3\",\n" +
                "          \"Q4\"\n" +
                "        )\n" +
                "      )\n" +
                "    )\n" +
                "    AS ?quarter\n" +
                "  )\n" +
                "}");

        enrichModelWithConstruct(model,"PREFIX ex: <http://example.org/>\n" +
                "CONSTRUCT {\n" +
                "  ?article ex:hasContentType ?contentType .\n" +
                "}\n" +
                "WHERE {\n" +
                "  ?article ex:type ?type .\n" +
                "  BIND (\n" +
                "    IF(?type = \"Actuality\", \"News Report\",\n" +
                "      IF(?type = \"Analyze\", \"In-depth Analysis\",\n" +
                "        \"General Interest\"\n" +
                "      )\n" +
                "    )\n" +
                "    AS ?contentType\n" +
                "  )\n" +
                "}");

        enrichModelWithConstruct(model,"PREFIX ex: <http://example.org/>\n" +
                "CONSTRUCT {\n" +
                "  ?author ex:hasExpertise ?expertise .\n" +
                "}\n" +
                "WHERE {\n" +
                "  SELECT ?author (SAMPLE(?topic) AS ?expertise) WHERE {\n" +
                "    ?article ex:author ?author .\n" +
                "    ?article ex:topic ?topic .\n" +
                "  }\n" +
                "  GROUP BY ?author\n" +
                "}");

        enrichModelWithConstruct(model,"PREFIX ex: <http://example.org/>\n" +
                "CONSTRUCT {\n" +
                "  ?article ex:appealsTo ?interestGroup .\n" +
                "}\n" +
                "WHERE {\n" +
                "  ?article ex:topic ?topic .\n" +
                "  BIND (\n" +
                "    IF(CONTAINS(LCASE(?topic), \"social media\"), \"Digital Culture\",\n" +
                "      IF(CONTAINS(LCASE(?topic), \"artificial intelligence\"), \"Tech Innovators\",\n" +
                "        IF(CONTAINS(LCASE(?topic), \"food\"), \"Culinary Enthusiasts\",\n" +
                "          \"General Audience\"\n" +
                "        )\n" +
                "      )\n" +
                "    )\n" +
                "    AS ?interestGroup\n" +
                "  )\n" +
                "}");

        enrichModelWithConstruct(model,"PREFIX ex: <http://example.org/>\n" +
                "CONSTRUCT {\n" +
                "  ?article1 ex:isRelatedTo ?article2 .\n" +
                "}\n" +
                "WHERE {\n" +
                "  ?article1 ex:author ?author1 .\n" +
                "  ?article2 ex:author ?author2 .\n" +
                "  ?article1 ex:topic ?topic1 .\n" +
                "  ?article2 ex:topic ?topic2 .\n" +
                "  FILTER (?article1 != ?article2)\n" +
                "  FILTER (?author1 = ?author2 || CONTAINS(LCASE(?topic1), LCASE(?topic2)) || CONTAINS(LCASE(?topic2), LCASE(?topic1)))\n" +
                "}");



        System.out.println("After enrichment:");
        countTriples(model);

        System.out.println("-------------------SPARQL Queries---------------------");

        SPARQLQueryExecutor.listArticlesByGenre(model);
        SPARQLQueryExecutor.listArticlesByLinguisticRegion(model,"Francophone");
        SPARQLQueryExecutor.listAuthorsAndExpertise(model);
        SPARQLQueryExecutor.listArticlesAndRelatedContent(model);
        SPARQLQueryExecutor.listArticlesByAudienceInterest(model);
        SPARQLQueryExecutor.listArticlesByPublicationQuarter(model);
        //SPARQLQueryExecutor.listArticlesBySpecificInterest(model, "Digital Culture");




    }



    private static void enrichModelWithConstruct(Model model, String constructQueryString) {
        Query query = QueryFactory.create(constructQueryString);
        try (QueryExecution qexec = QueryExecutionFactory.create(query, model)) {
            Model resultModel = qexec.execConstruct();
            model.add(resultModel);
        }
    }

    private static void countTriples(Model model) {
        String queryString = "SELECT (COUNT(*) AS ?numberOfTriples) WHERE { ?s ?p ?o . }";
        Query query = QueryFactory.create(queryString);
        try (QueryExecution qexec = QueryExecutionFactory.create(query, model)) {
            ResultSet results = qexec.execSelect();
            if (results.hasNext()) {
                QuerySolution soln = results.nextSolution();
                Literal count = soln.getLiteral("numberOfTriples");
                System.out.println(" model has " + count.getString() + " triples.");
            }
        }
    }

}
