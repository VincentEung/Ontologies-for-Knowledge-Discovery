package applications;

import org.apache.jena.rdf.model.Model;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.Query;

public class SPARQLConstructEnhancer {

	public static void enrichModelWithGenres(Model model) {
	    String queryString =
	        "PREFIX ex: <http://example.org/>\n" +
	        "CONSTRUCT {\n" +
	        "  ?article ex:hasGenre ?genre .\n" +
	        "}\n" +
	        "WHERE {\n" +
	        "  ?article ex:topic ?topic .\n" +
	        "  BIND (\n" +
	        "    IF(CONTAINS(LCASE(?topic), \"technology\"), \"Technology\",\n" +
	        "      IF(CONTAINS(LCASE(?topic), \"food\"), \"Culinary\",\n" +
	        "        IF(CONTAINS(LCASE(?topic), \"life\"), \"Lifestyle\",\n" +
	        "          IF(CONTAINS(LCASE(?topic), \"Artificial Intelligence\"), \"Technology\",\n" +
	        "            IF(CONTAINS(LCASE(?topic), \"cinema\"), \"Cinema\",\n" +
	        "              IF(CONTAINS(LCASE(?topic), \"social\"), \"Social\",\n" +
	        "                \"Other\"\n" +
	        "              )\n" +
	        "            )\n" +
	        "          )\n" +
	        "        )\n" +
	        "      )\n" +
	        "    ) AS ?genre\n" +
	        "  )\n" +
	        "}";

	    executeConstructQuery(model, queryString);
	}




    public static void linkArticlesToLinguisticRegions(Model model) {
        String queryString =
            "PREFIX ex: <http://example.org/>\n" +
            "CONSTRUCT {\n" +
            "  ?article ex:targetsLinguisticRegion ?region .\n" +
            "}\n" +
            "WHERE {\n" +
            "  ?article ex:language ?lang .\n" +
            "  BIND (\n" +
            "    IF(?lang = \"French\", \"Francophone\",\n" +
            "      IF(?lang = \"English\", \"Anglophone\",\n" +
            "        \"Other\"\n" +
            "      )\n" +
            "    )\n" +
            "    AS ?region\n" +
            "  )\n" +
            "}";

        executeConstructQuery(model, queryString);
    }

    public static void categorizeArticlesByPublicationQuarter(Model model) {
        String queryString =
            "PREFIX ex: <http://example.org/>\n" +
            "PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n" +
            "CONSTRUCT {\n" +
            "  ?article ex:publishedInQuarter ?quarter .\n" +
            "}\n" +
            "WHERE {\n" +
            "  ?article ex:date ?date .\n" +
            "  BIND (\n" +
            "    IF(MONTH(xsd:dateTime(?date)) >= 1 && MONTH(xsd:dateTime(?date)) <= 3, \"Q1\",\n" +
            "      IF(MONTH(xsd:dateTime(?date)) >= 4 && MONTH(xsd:dateTime(?date)) <= 6, \"Q2\",\n" +
            "        IF(MONTH(xsd:dateTime(?date)) >= 7 && MONTH(xsd:dateTime(?date)) <= 9, \"Q3\",\n" +
            "          \"Q4\"\n" +
            "        )\n" +
            "      )\n" +
            "    )\n" +
            "    AS ?quarter\n" +
            "  )\n" +
            "}";

        executeConstructQuery(model, queryString);
    }



    public static void associateArticlesWithContentType(Model model) {
        String queryString =
            "PREFIX ex: <http://example.org/>\n" +
            "CONSTRUCT {\n" +
            "  ?article ex:hasContentType ?contentType .\n" +
            "}\n" +
            "WHERE {\n" +
            "  ?article ex:type ?type .\n" +
            "  BIND (\n" +
            "    IF(?type = \"Actuality\", \"News Report\",\n" +
            "      IF(?type = \"Analyze\", \"In-depth Analysis\",\n" +
            "        \"General Interest\"\n" +
            "      )\n" +
            "    )\n" +
            "    AS ?contentType\n" +
            "  )\n" +
            "}";

        executeConstructQuery(model, queryString);
    }

    public static void tagArticlesByAuthorsExpertise(Model model) {
        String queryString =
            "PREFIX ex: <http://example.org/>\n" +
            "CONSTRUCT {\n" +
            "  ?author ex:hasExpertise ?expertise .\n" +
            "}\n" +
            "WHERE {\n" +
            "  SELECT ?author (SAMPLE(?topic) AS ?expertise) WHERE {\n" +
            "    ?article ex:author ?author .\n" +
            "    ?article ex:topic ?topic .\n" +
            "  }\n" +
            "  GROUP BY ?author\n" +
            "}";

        executeConstructQuery(model, queryString);
    }

    public static void inferPotentialAudienceInterest(Model model) {
        String queryString =
            "PREFIX ex: <http://example.org/>\n" +
            "CONSTRUCT {\n" +
            "  ?article ex:appealsTo ?interestGroup .\n" +
            "}\n" +
            "WHERE {\n" +
            "  ?article ex:topic ?topic .\n" +
            "  BIND (\n" +
            "    IF(CONTAINS(LCASE(?topic), \"social media\"), \"Digital Culture\",\n" +
            "      IF(CONTAINS(LCASE(?topic), \"artificial intelligence\"), \"Tech Innovators\",\n" +
            "        IF(CONTAINS(LCASE(?topic), \"food\"), \"Culinary Enthusiasts\",\n" +
            "          \"General Audience\"\n" +
            "        )\n" +
            "      )\n" +
            "    )\n" +
            "    AS ?interestGroup\n" +
            "  )\n" +
            "}";

        executeConstructQuery(model, queryString);
    }

    public static void linkRelatedArticles(Model model) {
        String queryString =
            "PREFIX ex: <http://example.org/>\n" +
            "CONSTRUCT {\n" +
            "  ?article1 ex:isRelatedTo ?article2 .\n" +
            "}\n" +
            "WHERE {\n" +
            "  ?article1 ex:author ?author1 .\n" +
            "  ?article2 ex:author ?author2 .\n" +
            "  ?article1 ex:topic ?topic1 .\n" +
            "  ?article2 ex:topic ?topic2 .\n" +
            "  FILTER (?article1 != ?article2)\n" +
            "  FILTER (?author1 = ?author2 || CONTAINS(LCASE(?topic1), LCASE(?topic2)) || CONTAINS(LCASE(?topic2), LCASE(?topic1)))\n" +
            "}";

        executeConstructQuery(model, queryString);
    }




    private static void executeConstructQuery(Model model, String queryString) {
        Query query = QueryFactory.create(queryString);
        try (QueryExecution qe = QueryExecutionFactory.create(query, model)) {
            Model resultModel = qe.execConstruct();
            if (!resultModel.isEmpty()) {
                System.out.println("New triples added:");
                resultModel.write(System.out, "Turtle");
            } else {
                System.out.println("No new triples were added.");
            }
        }
    }

}
