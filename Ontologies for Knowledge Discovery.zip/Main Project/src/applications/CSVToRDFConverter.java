package applications;

import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Resource;
import org.apache.jena.vocabulary.RDFS;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class CSVToRDFConverter {

    private static String encodeSpaces(String uriComponent) {
        return uriComponent.replace(" ", "%20");
    }

    public static void convertToRDF(List<Article> articles, String outputFile) {
        Model model = ModelFactory.createDefaultModel();

        String exPrefix = "http://example.org/";
        model.setNsPrefix("ex", exPrefix);

        // Définir les classes et sous-classes
        Resource articleClass = model.createResource(exPrefix + "Article");
        Resource authorClass = model.createResource(exPrefix + "Author");
        Resource cinemaClass = model.createResource(exPrefix + "Cinema");
        Resource socialMediaClass = model.createResource(exPrefix + "SocialMedia");
        Resource paysageMediatiqueClass = model.createResource(exPrefix + "PaysageMediatique");

        cinemaClass.addProperty(RDFS.subClassOf, articleClass);
        socialMediaClass.addProperty(RDFS.subClassOf, articleClass);
        paysageMediatiqueClass.addProperty(RDFS.subClassOf, articleClass);

        for (Article article : articles) {
            String domain = article.getArticleMainDomain().replace(" ", ""); // Assurez-vous que le domaine ne contient pas d'espaces
            Resource domainResource = getDomainResource(model, domain, exPrefix);
            if (domainResource == null) {
                System.out.println("Domaine inconnu pour l'article: " + article.getArticleTitle());
                continue; // Skip this article if the domain is unknown
            }
            Resource articleResource = model.createResource(exPrefix + "article#" + encodeSpaces(article.getId()), domainResource);

            // Création de l'auteur comme ressource distincte avec l'encodage des espaces
            String encodedAuthorName = encodeSpaces(article.getArticleAuthorName());
            Resource authorResource = model.createResource(exPrefix + "author#" + encodedAuthorName, authorClass);
            articleResource.addProperty(model.createProperty(exPrefix + "author"), authorResource);


            // Ajouter les autres propriétés
            articleResource.addProperty(model.createProperty(exPrefix + "source"), article.getArticleSource())
                           .addProperty(model.createProperty(exPrefix + "title"), article.getArticleTitle())
                           .addProperty(model.createProperty(exPrefix + "date"), article.getArticleDate())
                           .addProperty(model.createProperty(exPrefix + "language"), article.getArticleLanguage())
                           .addProperty(model.createProperty(exPrefix + "type"), article.getArticleType())
                           .addProperty(model.createProperty(exPrefix + "topic"), article.getArticleTopics());
        }

        try {
            FileOutputStream out = new FileOutputStream(outputFile);
            model.write(out, "RDF/XML-ABBREV");
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static Resource getDomainResource(Model model, String domain, String exPrefix) {
        switch (domain) {
            case "Cinema":
                return model.createResource(exPrefix + "Cinema");
            case "SocialMedia":
                return model.createResource(exPrefix + "SocialMedia");
            case "PaysageMediatique":
                return model.createResource(exPrefix + "PaysageMediatique");
            default:
                System.out.println("Domaine inconnu: " + domain);
                return null;
        }
    }
}
