package applications;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

public class CSVReader {
	public static List<Article> readCSV(String filePath) {
	    List<Article> articles = new ArrayList<>();

	    try {
	        Reader reader = new FileReader(filePath);
	        CSVParser csvParser = CSVParser.parse(reader, CSVFormat.DEFAULT.withDelimiter(';').withHeader(
	                "ID", "Article_link", "Article_title", "Article_date", "Article_author_name",
	                "Article_topics", "Article_main_domain", "Article_source", "Article_language", "Article_type"
	        ));

	        // Skip the first record (header)
	        csvParser.iterator().next();

	        for (CSVRecord csvRecord : csvParser) {
	            String id = csvRecord.get("ID");
	            String articleLink = csvRecord.get("Article_link");
	            String articleTitle = csvRecord.get("Article_title");
	            String articleDate = csvRecord.get("Article_date");
	            String articleAuthorName = csvRecord.get("Article_author_name");
	            String articleTopics = csvRecord.get("Article_topics");
	            String articleMainDomain = csvRecord.get("Article_main_domain");
	            String articleSource = csvRecord.get("Article_source");
	            String articleLanguage = csvRecord.get("Article_language");
	            String articleType = csvRecord.get("Article_type");

	            Article article = new Article(id, articleLink, articleTitle, articleDate, articleAuthorName,
	                    articleTopics, articleMainDomain, articleSource, articleLanguage, articleType);
	            articles.add(article);
	        }

	        csvParser.close();
	        reader.close();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }

	    return articles;
	}

}
