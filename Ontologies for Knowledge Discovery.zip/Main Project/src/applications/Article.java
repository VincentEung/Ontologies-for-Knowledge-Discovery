package applications;

public class Article {
    private String id;
    private String articleLink;
    private String articleTitle;
    private String articleDate;
    private String articleAuthorName;
    private String articleTopics;
    private String articleMainDomain;
    private String articleSource;
    private String articleLanguage;
    private String articleType;

    
    // Constructeur
    public Article(String id, String articleLink, String articleTitle, String articleDate, String articleAuthorName, String articleTopics, String articleMainDomain, String articleSource, String articleLanguage, String articleType) {
        this.id = id;
        this.articleLink = articleLink;
        this.articleTitle = articleTitle;
        this.articleDate = articleDate;
        this.articleAuthorName = articleAuthorName;
        this.articleTopics = articleTopics;
        this.articleMainDomain = articleMainDomain;
        this.articleSource = articleSource;
        this.articleLanguage = articleLanguage;
        this.articleType = articleType;
    }

    // Getters
    public String getId() { return id; }
    public String getArticleLink() { return articleLink; }
    public String getArticleTitle() { return articleTitle; }
    public String getArticleDate() { return articleDate; }
    public String getArticleAuthorName() { return articleAuthorName; }
    public String getArticleTopics() { return articleTopics; }
    public String getArticleMainDomain() { return articleMainDomain; }
    public String getArticleSource() { return articleSource; }
    public String getArticleLanguage() { return articleLanguage; }
    public String getArticleType() { return articleType; }
    
    // Vous pouvez également inclure des setters si nécessaire
 // Setters
    public void setId(String id) { this.id = id; }
    public void setArticleLink(String articleLink) { this.articleLink = articleLink; }
    public void setArticleTitle(String articleTitle) { this.articleTitle = articleTitle; }
    public void setArticleDate(String articleDate) { this.articleDate = articleDate; }
    public void setArticleAuthorName(String articleAuthorName) { this.articleAuthorName = articleAuthorName; }
    public void setArticleTopics(String articleTopics) { this.articleTopics = articleTopics; }
    public void setArticleMainDomain(String articleMainDomain) { this.articleMainDomain = articleMainDomain; }
    public void setArticleSource(String articleSource) { this.articleSource = articleSource; }
    public void setArticleLanguage(String articleLanguage) { this.articleLanguage = articleLanguage; }
    public void setArticleType(String articleType) { this.articleType = articleType; }
}
