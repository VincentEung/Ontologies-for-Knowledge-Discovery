	package applications;
	
	import org.apache.jena.rdf.model.Model;
	import org.apache.jena.query.QueryExecution;
	import org.apache.jena.query.QueryExecutionFactory;
	import org.apache.jena.query.QueryFactory;
	import org.apache.jena.query.ResultSet;
	import org.apache.jena.query.ResultSetFormatter;
	import org.apache.jena.query.Query;
	
	public class SPARQLQueryExecutor {
	
		public static void listArticlesByGenre(Model model) {
		    String queryString = 
		        "PREFIX ex: <http://example.org/>\n" +
		        "SELECT ?genre (COUNT(?article) AS ?count) WHERE {\n" +
		        "  ?article ex:hasGenre ?genre .\n" +
		        "} GROUP BY ?genre ORDER BY DESC(?count)";
		    executeSelectQuery(model, queryString, "Articles by Genre:");
		}
		
	
	
		public static void listArticlesByLinguisticRegion(Model model, String region) {
		    String queryString = 
		        "PREFIX ex: <http://example.org/>\n" +
		        "SELECT ?article ?title WHERE {\n" +
		        "  ?article ex:targetsLinguisticRegion \"" + region + "\" ;\n" +
		        "           ex:title ?title .\n" +
		        "} ORDER BY ?title";
		    executeSelectQuery(model, queryString, "Articles Targeting " + region + " Region:");
		}
	
	
		public static void listAuthorsAndExpertise(Model model) {
		    String queryString = 
		        "PREFIX ex: <http://example.org/>\n" +
		        "SELECT ?author ?expertise WHERE {\n" +
		        "  ?author ex:hasExpertise ?expertise .\n" +
		        "} ORDER BY ?author";
		    executeSelectQuery(model, queryString, "Authors and Their Expertise:");
		}
	
		public static void listArticlesAndRelatedContent(Model model) {
		    String queryString = 
		        "PREFIX ex: <http://example.org/>\n" +
		        "SELECT ?article ?relatedArticle WHERE {\n" +
		        "  ?article ex:isRelatedTo ?relatedArticle .\n" +
		        "} ORDER BY ?article";
		    executeSelectQuery(model, queryString, "Articles and Related Content:");
		}
	
	
		public static void listArticlesByAudienceInterest(Model model) {
		    String queryString = 
		        "PREFIX ex: <http://example.org/>\n" +
		        "SELECT ?interestGroup (COUNT(?article) AS ?count) WHERE {\n" +
		        "  ?article ex:appealsTo ?interestGroup .\n" +
		        "} GROUP BY ?interestGroup ORDER BY DESC(?count)";
		    executeSelectQuery(model, queryString, "Articles Categorized by Audience Interest:");
		}
		public static void listArticlesByPublicationQuarter(Model model) {
		    String queryString = 
		        "PREFIX ex: <http://example.org/>\n" +
		        "SELECT ?quarter (COUNT(?article) AS ?count) WHERE {\n" +
		        "  ?article ex:publishedInQuarter ?quarter .\n" +
		        "} GROUP BY ?quarter ORDER BY ?quarter";
		    executeSelectQuery(model, queryString, "Articles by Publication Quarter:");
		}
		public static void listArticlesBySpecificInterest(Model model, String interestGroup) {
		    String queryString = 
		        "PREFIX ex: <http://example.org/>\n" +
		        "SELECT ?title ?date ?authorName WHERE {\n" +
		        "  ?article ex:appealsTo \"" + interestGroup + "\" ;\n" +
		        "           ex:title ?title ;\n" +
		        "           ex:date ?date ;\n" +
		        "           ex:author ?author .\n" +
		        "  ?author ex:name ?authorName .\n" +
		        "} ORDER BY DESC(?date)";
		    executeSelectQuery(model, queryString, "Articles for " + interestGroup + " Interest Group:");
		}




		
		
		
	
	
	    
		private static void executeSelectQuery(Model model, String queryString, String queryDescription) {
		    System.out.println(queryDescription);
		    Query query = QueryFactory.create(queryString);
		    try (QueryExecution qe = QueryExecutionFactory.create(query, model)) {
		        ResultSet results = qe.execSelect();
		        ResultSetFormatter.out(System.out, results, query);
		        System.out.println(); 
		    }
		}
	
	
	    
	}
