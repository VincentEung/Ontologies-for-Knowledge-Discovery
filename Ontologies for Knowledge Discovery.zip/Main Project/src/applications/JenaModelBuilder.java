package applications;

import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Property;
import org.apache.jena.rdf.model.Resource;
import org.apache.jena.rdf.model.Literal;
import org.apache.jena.datatypes.xsd.XSDDatatype;
import java.util.List;


import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.Property;
import org.apache.jena.rdf.model.Resource;
import org.apache.jena.rdf.model.Literal;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.Query;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;

public class JenaModelBuilder {
    public static Model createJenaModel(List<Article> articles) {
        Model model = ModelFactory.createDefaultModel();

        String baseURI = "http://example.org/";
        
        // Assurez-vous que ces propriétés correspondent à celles de votre RDF
        Property hasTitle = model.createProperty(baseURI, "title");
        Property hasDate = model.createProperty(baseURI, "date");
        Property hasAuthor = model.createProperty(baseURI, "author");
        Property hasTopic = model.createProperty(baseURI, "topic");
        Property hasLink = model.createProperty(baseURI, "link");
        Property hasMainDomain = model.createProperty(baseURI, "mainDomain");
        Property hasSource = model.createProperty(baseURI, "source");
        Property hasLanguage = model.createProperty(baseURI, "language");
        Property hasType = model.createProperty(baseURI, "type");
        
        // Adapté pour correspondre aux classes de votre RDF
        Resource cinemaResource = model.createResource(baseURI + "Cinema");
        Resource socialMediaResource = model.createResource(baseURI + "SocialMedia");
        Resource paysageMediatiqueResource = model.createResource(baseURI + "PaysageMediatique");
        
        for (Article article : articles) {
            // Utilisez l'URI correcte pour chaque article en fonction de son domaine principal
            Resource articleResource = model.createResource(baseURI + "article/" + article.getId());
            
            // Ajoutez les propriétés à l'article
            articleResource.addProperty(hasTitle, article.getArticleTitle())
                            .addProperty(hasDate, article.getArticleDate(), XSDDatatype.XSDdate) // Utilisation de XSDDatatype pour les dates
                            .addProperty(hasAuthor, model.createResource(baseURI + "author/" + encodeSpaces(article.getArticleAuthorName()))) // Crée une ressource pour l'auteur
                            .addProperty(hasTopic, article.getArticleTopics())
                            .addProperty(hasLink, article.getArticleLink())
                            .addProperty(hasMainDomain, determineDomainResource(article.getArticleMainDomain(), cinemaResource, socialMediaResource, paysageMediatiqueResource))
                            .addProperty(hasSource, article.getArticleSource())
                            .addProperty(hasLanguage, article.getArticleLanguage())
                            .addProperty(hasType, article.getArticleType());
        }
        return model;
    }
    
    // Cette méthode détermine la ressource de domaine correcte en fonction du domaine principal de l'article
    private static Resource determineDomainResource(String domain, Resource cinema, Resource socialMedia, Resource paysageMediatique) {
        switch (domain.toLowerCase()) {
            case "cinema":
                return cinema;
            case "socialmedia":
                return socialMedia;
            case "paysagemediatique":
                return paysageMediatique;
            default:
                return null; // Gérer les cas où le domaine n'est pas reconnu
        }
    }

    // Encodez les espaces dans les noms d'auteur pour une utilisation dans les URI
    private static String encodeSpaces(String value) {
        return value.replace(" ", "%20");
    }
    
    public static void retrieveLatestArticles(Model model) {
        // Définir la requête SPARQL pour récupérer les articles les plus récents
    	String queryString = 
    	        "PREFIX ex: <http://example.org/> " +
    	        "SELECT ?article ?title ?date " +
    	        "WHERE { " +
    	        "  ?article ex:title ?title . " +
    	        "  ?article ex:date ?date . " +
    	        "} ORDER BY DESC(?date)";

        // Exécuter la requête SPARQL et récupérer les résultats
        try (QueryExecution qexec = QueryExecutionFactory.create(queryString, model)) {
            ResultSet results = qexec.execSelect();

            // Parcourir les résultats et afficher les articles les plus récents
            while (results.hasNext()) {
                QuerySolution soln = results.nextSolution();
                String article = soln.getResource("article").getURI();
                String title = soln.getLiteral("title").getString();
                String date = soln.getLiteral("date").getString();
                System.out.println("Article: " + article + ", Title: " + title + ", Date: " + date);
            }
        }
    }
	
	public static void analyzePopularDomains(Model model) {
	    // Définir la requête SPARQL pour compter le nombre d'articles par domaine
		String queryString = 
		        "PREFIX ex: <http://example.org/> " +
		        "SELECT ?domain (COUNT(?article) AS ?count) " +
		        "WHERE { " +
		        "  ?article ex:mainDomain ?domain . " +
		        "} GROUP BY ?domain " +
		        "ORDER BY DESC(?count)";

		
	    // Exécuter la requête SPARQL et récupérer les résultats
	    try (QueryExecution qexec = QueryExecutionFactory.create(queryString, model)) {
	        ResultSet results = qexec.execSelect();

	        // Parcourir les résultats et afficher les sujets les plus populaires
	        while (results.hasNext()) {
	            QuerySolution soln = results.nextSolution();
	            // Suppose que ?domain est une URI et donc récupérée comme une Resource
	            Resource domain = soln.getResource("domain"); // Utilise getResource pour obtenir la Resource
	            // Suppose que ?count est une valeur littérale (nombre d'articles) et donc récupérée comme une Literal
	            Literal count = soln.getLiteral("count"); // Utilise getLiteral pour obtenir la Literal
	            
	            // Affichage des résultats
	            System.out.println("Domain: " + domain.getURI() + ", Number of articles: " + count.getInt());
	        }

	    }
	}
	
	public static void findArticlesWithActualityType(Model model) {
        // Définir la requête SPARQL pour récupérer les articles avec le type "Actuality"
		String queryString = 
		        "PREFIX ex: <http://example.org/> " +
		        "SELECT ?article ?title " +
		        "WHERE { " +
		        "  ?article ex:title ?title . " +
		        "  ?article ex:type \"Actuality\" . " +
		        "}";

        // Exécuter la requête SPARQL et récupérer les résultats
        try (QueryExecution qexec = QueryExecutionFactory.create(queryString, model)) {
            ResultSet results = qexec.execSelect();

            // Parcourir les résultats et afficher les articles avec le type "Actuality"
            while (results.hasNext()) {
                QuerySolution soln = results.nextSolution();
                String article = soln.getResource("article").getURI();
                String title = soln.getLiteral("title").getString();
                System.out.println("Article: " + article + ", Title: " + title);
            }
        }
    }
	
	public static void findArticlesWithAnalyzeType(Model model) {
	    // Définir la requête SPARQL pour récupérer les articles avec le type "Analyze" et leur auteur
		String queryString = 
		        "PREFIX ex: <http://example.org/> " +
		        "SELECT ?article ?title ?author " +
		        "WHERE { " +
		        "  ?article ex:title ?title . " +
		        "  ?article ex:type \"Analyze\" . " +
		        "  ?article ex:author ?author . " +
		        "}";

	    // Exécuter la requête SPARQL et récupérer les résultats
	    try (QueryExecution qexec = QueryExecutionFactory.create(queryString, model)) {
	        ResultSet results = qexec.execSelect();

	        // Parcourir les résultats et afficher les articles avec le type "Analyze" et leur auteur
	        while (results.hasNext()) {
	            QuerySolution soln = results.nextSolution();
	            // Récupère l'URI de l'article, qui est une ressource
	            Resource article = soln.getResource("article");
	            // Supposons que le titre soit une valeur littérale
	            Literal title = soln.getLiteral("title");
	            // Récupère l'URI de l'auteur, qui pourrait être retourné comme une ressource si vous l'avez modélisé ainsi
	            Resource author = soln.getResource("author"); // Modifiez ceci selon votre modèle de données

	            // Affichage des résultats
	            System.out.println("Article: " + article.getURI() + ", Title: " + title.getString() + ", Author: " + author.getURI());
	        }

	    }
	}
	
	public static void countArticlesByLanguage(Model model) {
        // Définir la requête SPARQL
		String queryString = 
		        "PREFIX ex: <http://example.org/> " +
		        "SELECT ?language (COUNT(?article) AS ?count) " +
		        "WHERE { " +
		        "  ?article ex:language ?language . " +
		        "} GROUP BY ?language";

        // Créer l'objet Query
        Query query = QueryFactory.create(queryString);

        // Exécuter la requête SPARQL et récupérer les résultats
        try (QueryExecution qexec = QueryExecutionFactory.create(query, model)) {
            ResultSet results = qexec.execSelect();

            // Parcourir les résultats et afficher le nombre d'articles par langue
            while (results.hasNext()) {
                QuerySolution soln = results.nextSolution();
                String language = soln.getLiteral("language").getString();
                int count = soln.getLiteral("count").getInt();
                System.out.println("Language: " + language + ", Number of Articles: " + count);
            }
        }
    }

	public static void filterArticlesByDate(Model model) {
        // Définir la requête SPARQL
		String queryString =
	            "PREFIX ex: <http://example.org/> " +
	            "PREFIX xsd: <http://www.w3.org/2001/XMLSchema#> " +
	            "SELECT ?article ?title ?date " +
	            "WHERE { " +
	            "  ?article ex:title ?title . " +
	            "  ?article ex:date ?date . " +
	            "  FILTER (?date > \"2024-01-01\"^^xsd:date) " +
	            "} ";

        // Créer l'objet Query
        Query query = QueryFactory.create(queryString);

        // Exécuter la requête SPARQL et récupérer les résultats
        try (QueryExecution qexec = QueryExecutionFactory.create(query, model)) {
            ResultSet results = qexec.execSelect();

            // Parcourir les résultats et afficher les articles répondant aux critères
            while (results.hasNext()) {
                QuerySolution soln = results.nextSolution();
                String article = soln.getResource("article").getURI();
                String title = soln.getLiteral("title").getString();
                String date = soln.getLiteral("date").getString();
                System.out.println("Article: " + article + ", Title: " + title + ", Date: " + date);
            }
        }
    }
	
	public static void allCinemaArticles(Model model) {
        // Définir la requête SPARQL
		String queryString = "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> " +
                "PREFIX ex: <http://example.org/> " +
                "SELECT ?title " +
                "WHERE {" +
                "   ?cinema ex:mainDomain \"Cinema\" ." +
                "}";

        // Créer une requête SPARQL
        Query query = QueryFactory.create(queryString);

        // Exécuter la requête et obtenir les résultats
        try (QueryExecution qexec = QueryExecutionFactory.create(query, model)) {
            ResultSet results = qexec.execSelect();
            // Parcourir les résultats et afficher les instances de Cinema
            while (results.hasNext()) {
                QuerySolution soln = results.nextSolution();
                // Récupérer la valeur de la variable ?cinema
                Resource cinema = soln.getResource("cinema");
                System.out.println("Instance de Cinema : " + cinema.getURI());
            }
        }
    }

	public static void findArticlesWithTitleContainingSpecificWord(Model model) {
        // Définir la requête SPARQL
		String queryString =
	            "PREFIX ex: <http://example.org/> " +
	            "SELECT ?article ?title " +
	            "WHERE { " +
	            "  ?article ex:title ?title . " +
	            "  FILTER regex(?title, \"Réseaux sociaux\", \"i\") . " +
	            "} ";

        // Créer l'objet Query
        Query query = QueryFactory.create(queryString);

        // Exécuter la requête SPARQL et récupérer les résultats
        try (QueryExecution qexec = QueryExecutionFactory.create(query, model)) {
            ResultSet results = qexec.execSelect();

            // Parcourir les résultats et afficher les articles dont le titre contient "cinema"
            while (results.hasNext()) {
                QuerySolution soln = results.nextSolution();
                String article = soln.getResource("article").getURI();
                String title = soln.getLiteral("title").getString();
                System.out.println("Article: " + article + ", Title: " + title);
            }
        }
    }
	
	public static void queryArticlesFromSource(Model model) {
        // Définir la requête SPARQL
		String queryString =
	            "PREFIX ex: <http://example.org/> " +
	            "SELECT ?article ?title " +
	            "WHERE {" +
	            "  ?article ex:title ?title ." +
	            "  ?article ex:source \"bbc.com\" ." +
	            "} ";

        // Créer l'objet Query
        Query query = QueryFactory.create(queryString);

        // Exécuter la requête SPARQL et récupérer les résultats
        try (QueryExecution qexec = QueryExecutionFactory.create(query, model)) {
            ResultSet results = qexec.execSelect();

            // Parcourir les résultats et afficher les articles provenant de "lemonde.fr"
            while (results.hasNext()) {
                QuerySolution soln = results.nextSolution();
                String articleURI = soln.getResource("article").getURI();
                String title = soln.getLiteral("title").getString();
                System.out.println("Article URI: " + articleURI + ", Title: " + title);
            }
        }
    }
	
	public static void queryArticlesByAuthor(Model model) {
        // Définir la requête SPARQL
		String queryString =
	            "PREFIX ex: <http://example.org/> " +
	            "SELECT ?article ?title " +
	            "WHERE {" +
	            "  ?article ex:title ?title ." +
	            "  ?article ex:author \"Aurélien%20Carle\" ." +
	            "} ";

        // Créer l'objet Query
        Query query = QueryFactory.create(queryString);

        // Exécuter la requête SPARQL et récupérer les résultats
        try (QueryExecution qexec = QueryExecutionFactory.create(query, model)) {
            ResultSet results = qexec.execSelect();

            // Parcourir les résultats et afficher les articles de l'auteur spécifié
            while (results.hasNext()) {
                QuerySolution soln = results.nextSolution();
                String articleURI = soln.getResource("article").getURI();
                String title = soln.getLiteral("title").getString();
                System.out.println("Article URI: " + articleURI + ", Title: " + title);
            }
        }
    }
	
    
}
